To run Object_detection2.py

Before running Yolo
1. install opencv 3.4.2
2. python version >=3.5.2

For Thrift:
change the ip in thrift code of your destination IP.

For YOLO:
please download yolov3.weights link is below and place in that folder
#  wget https://pjreddie.com/media/files/yolov3.weights



