import glob
import sys

from thrift import Thrift
from thrift.protocol import TBinaryProtocol
from thrift.transport import TSocket, TTransport

import HelloWorldService


try :
  transport = TSocket.TSocket(host = '192.168.43.14',port = '9091')
  transport = TTransport.TBufferedTransport(transport)
  protocol = TBinaryProtocol.TBinaryProtocol(transport)
  client = HelloWorldService.Client(protocol)
  transport.open()
  print(client.hello("aeroplane"))
 

  transport.close()
    
except Exception as e:
  print(e)

